!!! Read this !!!
Check out the video "how to run the project" to know what you need to do.

Link to the video:
https://drive.google.com/file/d/1ZDFv2US8l6L3GpNiG5KeMbiJXiQCNIJU/view?usp=sharing

- Credits
The Backend folder:
// written by: Virak
// tested by: Virak
// debugged by: Virak

The myapp folder(this is the frontend)
+ app folder:
    // written by: Virak
    // tested by: Virak
    // debugged by: Virak
+ Lesson.tsx:
    // written by: Harvey
    // tested by: Harvey
    // debugged by: Harvey
    // Assisted by: Virak
+ HomePage.tsx, ListOfExercise.tsx:
    // written by: Harvey
    // tested by: Harvey
    // debugged by: Harvey
+ FromInput.tsx, Login.tsx, Register_email.tsx, SubmitBtn.tsx:
    // written by: Virak
    // tested by: Virak
    // debugged by: Virak
App Design:
    Designed by: Viputh
