# Project Khmer

We will named this project "Project Khmer" for now. In the future when we can think of a more suitable name we will rename it. 
This project will help cambodian people learn more about other languages. It is similar to an app called duolingo but khmer language will be the priority.

# Link to project design
[Project design link](https://www.figma.com/file/9Dv82fsa2Vw1DiootivyUX/Project?type=design&node-id=0%3A1&mode=design&t=ikUyCQL367r2jD6a-1)

